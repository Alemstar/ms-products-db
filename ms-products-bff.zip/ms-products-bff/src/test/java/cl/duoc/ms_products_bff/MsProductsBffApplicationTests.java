package cl.duoc.ms_products_bff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProductsBffApplicationTests {

	@Test
	void contextLoads() {
	}

}
