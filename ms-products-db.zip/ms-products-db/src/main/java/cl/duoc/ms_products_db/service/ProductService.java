package cl.duoc.ms_products_db.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duoc.ms_products_db.model.dto.ProductDTO;
import cl.duoc.ms_products_db.model.entities.Product;
import cl.duoc.ms_products_db.model.repository.ProductRepository;
import jakarta.persistence.PreUpdate;

@Service
public class ProductService {
    @Autowired
    ProductRepository productRepository;

    public ProductDTO translateEntityToDTO(Product product){

        ProductDTO productDTO = new ProductDTO();
        productDTO.setIdProduct(product.getIdProduct());
        productDTO.setProductName(product.getProductName());
        productDTO.setPrice(product.getPrice());
        productDTO.setStock(product.getStock());

        return productDTO;
    }

    public ProductDTO getProductById(Long idProduct){

        Optional<Product> product = productRepository.findById(idProduct);

        ProductDTO productDTO = null;

        if(product.isPresent())
            return productDTO = translateEntityToDTO(product.get());
        else
            return productDTO;
    }

    public List<ProductDTO> translateListEntityToDTO(List<Product> product){

        List<ProductDTO> listDTO = new ArrayList<>();
        ProductDTO productDTO = null;
        for (Product prod: product){
            productDTO = new ProductDTO();
            productDTO.setIdProduct(prod.getIdProduct());
            productDTO.setProductName(prod.getProductName());
            productDTO.setPrice(prod.getPrice());
            productDTO.setStock(prod.getStock());

            listDTO.add(productDTO);
        }
        return listDTO; 
    }

    public List<ProductDTO> selectAllProduct(){

        List<Product> productsList = productRepository.findAll();
        List<ProductDTO> productsListDTO = translateListEntityToDTO(productsList);
        return productsListDTO;
    }
    
    public Product translateDtoToEntity(ProductDTO productDTO){
        Product product = new Product();
        product.setIdProduct(productDTO.getIdProduct());
        product.setProductName(productDTO.getProductName());
        product.setPrice(productDTO.getPrice());
        product.setStock(productDTO.getStock());

        return product;
    }

    public Product insertProduct(ProductDTO productDTO){

        Product newProduct = translateDtoToEntity(productDTO);
        productRepository.save(newProduct);

        return newProduct;
    }

    public String deleteProduct(Long idProduct){

        productRepository.deleteById(idProduct);
        return "Product deleted";
    }

    public Product updateProduct(ProductDTO productDTO){
        return;
    }
}