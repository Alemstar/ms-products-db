package cl.duoc.ms_products_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsProductsDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsProductsDbApplication.class, args);
	}

}
