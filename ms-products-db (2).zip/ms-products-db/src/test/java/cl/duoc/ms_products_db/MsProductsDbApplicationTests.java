package cl.duoc.ms_products_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsProductsDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
